const db = require("../models");



const ScheduleServicesHost = async (HostId) => {
  try {
    const schedule = await db.schedule.findAll({
      where: { Host: HostId }
    })
    return schedule;
  } catch (error) {
    console.log(error);
    return { error }
  }
}

const DeleteScheduleHost = async (HouseId) => {
  try {
    // const scheduel = await db.scheduel.findAll({
    //   where: {HouseId: HouseId}
    // })

    // if (scheduel.length > 0) {
    //   const deleteAllData = await Promise.all(
    //     scheduel.map((img) => img.destroy())
    //   );
    //   return deleteAllData;
    // }
    const deleteSchedule = await db.schedule.destroy({ where: { HouseId: HouseId } });
    return deleteSchedule;
  } catch (error) {
    console.log(error);
    return { error }
  }
}

const ModifierScheduleHost = async (data, id) => {
  try {
    const entity = await db.schedule.findOne({where: {HouseId: id}});
    console.log('data',data);
    console.log('entity',entity);
    if (entity) {
      await entity.update({Date: data});
      return true;
    }

  } catch (error) {
    console.log(error);
    return { error };
  }
}

module.exports = {
  ScheduleServicesHost: ScheduleServicesHost,
  DeleteScheduleHost: DeleteScheduleHost,
  ModifierScheduleHost: ModifierScheduleHost
}