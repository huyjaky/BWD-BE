const { Op } = require("sequelize");
const db = require("../models");
const Sequelize = require('sequelize');

const FilterService = async (
  { amenities, bathRooms, beds, hostLanguage, maxPrice, minPrice, typeHouse, orientation },
  { address, checkInDay, checkOutDay, guest },
  page, UserId
) => {
  const {
    countryRegion,
    locality,
    adminDistrict,
    countryRegionIso2,
    postalCode,
    addressLine,
    streetName,
    formattedAddress,
    latitude,
    longitude,
    title
  } = address;

  const {
    adults,
    childrens,
    infants
  } = guest;

  // gop cac mang ammenties neu no ton tai
  // const { essentials, features, location, safety } = amenities;

  const arrFil = amenities
  const filter = {};

  if (adults != 0 || childrens != 0 || infants != 0) {
    filter.beds = { NumsOfBed: { [Op.lte]: adults + childrens - 1 } }
  }

  if (orientation) {
    console.log('fil orien');
    filter.orientation = { Orientation: orientation }
  }

  if (bathRooms != 0) {
    console.log('fil bathR');
    filter.bathRooms = { NumsOfBath: bathRooms };
  }

  if (beds != 0) {
    console.log('filbeds');
    filter.beds = { NumsOfBed: beds };
  }

  if (hostLanguage) {
    console.log('filhost');
    filter.hostLanguage = { HostLanguage: hostLanguage };
  }

  if (maxPrice == 500000) maxPrice = 99999999;

  filter.price = { Price: { [Op.between]: [minPrice, maxPrice] } };

  // bo loc typehouse va amenities
  let houseIdArr = [];
  if (typeHouse.length != 0) {
    const houseIdTypeHouse = await handleFetchTypeHouse(typeHouse);
    houseIdArr = houseIdTypeHouse.map((item, index) => {
      return item.dataValues.HouseId
    })
  }

  if (arrFil.length != 0) {
    const houseIdPlaceOffer = await handleFetchPlaceOffer(arrFil);
    if (houseIdArr.length == 0) {
      houseIdArr = houseIdPlaceOffer.map((item, index) => {
        return item.dataValues
      })
    } else {
      let arrTemp = [];
      for (const item of houseIdPlaceOffer) {
        if (houseIdArr.includes(item.dataValues.HouseId)) {
          arrTemp.push(item.dataValues.HouseId)
        }
      }
      console.log(arrTemp);
      houseIdArr = arrTemp;
    }
  }

  if (houseIdArr.length != 0) {
    filter.typehouseAme = { HouseId: { [Op.in]: houseIdArr } }
  } else {
    houseIdArr = ['123123123123123123123123']
    filter.typehouseAme = { HouseId: { [Op.in]: houseIdArr } }
  }

  console.log('houseIdArr', houseIdArr);



  // dinh nghia include va push nhung filter can thiet
  const include = [
    {
      model: db.useracc,
      required: true,
      attributes: ["UserId", "UserName", "Gmail", "Image", "Phone"],
    },
  ];

  if (addressLine) {
    console.log('address line', addressLine);
    include.push({
      model: db.address,
      required: true,
      where: { latitude: latitude, longitude: longitude },
    });
  } else {
    include.push({
      model: db.address,
      required: true,
    });
  }

  let perPage = 10;
  let offSet = (Math.floor(parseInt(page)) - 1) * page;
  // let offSet = parseInt(page);


  if (page == -1) {
    perPage = 7;
    offSet = 0
  } else if (page == -2) {
    perPage = 99;
    offSet = 1
  }
  // console.log(page);
  // console.log('offset', offSet);
  // console.log('limit', perPage);

  try {
    const getHouse_ = await db.house.findAll({
      where: {
        [Op.and]: [
          filter.beds,
          filter.bathRooms,
          filter.hostLanguage,
          filter.price,
          filter.orientation,
          filter.typehouseAme
        ],
      },

      include: include,
      limit: perPage,
      offset: offSet,
    });


    let extendedHouse = await Promise.all(
      getHouse_.map(async (item) => {
        const arrImg = await handleFetchImg(item.HouseId);
        // const placeOffer = await handleFetchPlaceOffer(item.HouseId, arrFil);
        // const typeHouse_ = await handleFetchTypeHouse(item.HouseId, typeHouse);
        if (UserId) {
          const setIsFavorite = await handleFavorite(item.HouseId, UserId);
          return { ...item.toJSON(), arrImg, IsFavorite: setIsFavorite };
        }
        return { ...item.toJSON(), arrImg }
      })
    );


    return extendedHouse;
  } catch (error) {
    console.log(error);
    return { error };
  }
};

const handleFavorite = async (HouseId, UserId) => {
  try {


    let isFavorite = await db.favorite.findAll({
      where: {
        [Op.and]: [
          { HouseId: HouseId },
          { UserId: UserId }
        ]
      }
    })
    if (isFavorite.length != 0) {
      return true;
    } else {
      return false;
    }
  } catch (error) {
    console.log(error);
    return;
  }
}

const handleFetchTypeHouse = async (typehouse) => {
  try {
    let getHousePlaceOffer = await db.house.findAll({
      attributes: ['HouseId'],
      include: [
        {
          model: db.managetypehouse,
          required: true,
          attributes: [],
          include: [
            {
              model: db.typehouse,
              required: true,
              attributes: [],
              where: { TypeHouse: { [Op.in]: typehouse } },
            },
          ],
        },
      ],
    });

    return getHousePlaceOffer;
  } catch (error) {
    console.log(error);
    return { error };
  }
};

const handleFetchPlaceOffer = async (amenities) => {
  try {
    let getHousePlaceOffer = await db.house.findAll({
      attributes: ['HouseId'],
      include: [
        {
          model: db.manageplaceoffer,
          required: true,
          attributes: [],
          include: [
            {
              model: db.placeoffer,
              required: true,
              attributes: [],
              where: { PlaceOffer: { [Op.in]: amenities } },
            },
          ],
        },
      ],
    });
    return getHousePlaceOffer;
  } catch (error) {
    console.log(error);
    return { error };
  }
};

const handleFetchImg = async (HouseId) => {
  try {
    let getHouseImg = await db.img.findAll({
      attributes: ["Path"],
      include: [
        {
          model: db.manageimg,
          required: true,
          attributes: [],
          include: [
            {
              model: db.house,
              required: true,
              where: { HouseId: HouseId },
              attributes: [],
            },
          ],
        },
      ],
    });
    return getHouseImg;
  } catch (error) {
    console.log(error);
    return { error };
  }
};

module.exports = {
  FilterService: FilterService,
};
