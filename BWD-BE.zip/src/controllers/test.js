

const test = (res, req) => {
  console.log('check');
  return ;
}

module.exports = {
  test: test
}